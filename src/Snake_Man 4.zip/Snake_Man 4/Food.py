class Food(object):
    
# Intergers
    global xpos
    global ypos

# Constructor        
    def __init__(self, xpos, ypos):
        self.xpos = xpos
        self.ypos = ypos
                   
    def display(self): # Display Method for Food
        Img = ["appleXuanthaoT.png", "bananaXuanthaoT.png"]
        random.choice(Img)
        
    def move(self): # Move Method for Food
        self.x
        self.y
        for i in range(x, y):
            r = random(x, y)
            r.display()
