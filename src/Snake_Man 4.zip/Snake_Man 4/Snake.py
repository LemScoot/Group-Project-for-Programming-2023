class Snake(object):

# Intergers
    global xpos
    global ypos
  
# Constructor
    def __init__(self, xpos, ypos):
        self.xpos = xpos
        self.ypos = ypos

    def move(self): # Move Method for Snake
        if(keyboard.is_pressed('w')):
            self.y = self.y - 0.1
        if(keyboard.is_pressed('s')):
            self.y = self.y + 0.1
        if(keyboard.is_pressed('a')):
            self.x = self.x - 0.1
        if(keyboard.is_pressed('d')):
            self.x = self.x + 0.1
            self.snake.goto(self.x,self.y)
            
    def display(x, y): # Display Method for Snake
        rect(random(xpos), random(ypos), 15, 15, 7)
        fill(255)
