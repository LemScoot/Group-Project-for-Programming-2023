import random 

class Food(object):

# Constructor        
    def __init__(self, grid_size, game_width, game_height):
        self.x = random.randint(0, game_width - grid_size)
        self.y = random.randint(0, grid_size - grid_size) 
        self.game_width = game_width
        self.game_height = game_height
        self.grid_size = grid_size
        
    def draw(self): # Display Method for Food
        food_img = random.choice(['appleXuanthaoT.png', 'bananaXuanthaoT.png'])
        image(loadImage(food_img), 0, 0)
       
    def move(self): # Move Method for Food
        self.x = random.randit(0, self.game_width - self.grid_size)
        self.y = random.randit(0, self.game_width - self.grid_size)
        
    def intersect(Snake, snake):
        s = dist(x, y, snake.x, snake.y)
        if (s < 50):
            return True
        else: 
            return False
