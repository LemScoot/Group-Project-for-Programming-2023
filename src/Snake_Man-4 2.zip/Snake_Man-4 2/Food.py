import random

GRID_SIZE = 100 #62.5

class Food:
    
    def __init__(self, width, height, size):
        self.x = 100
        self.y = 100
        self.width = width
        self.height = height
        self.size = 62.5
        self.rand = False
        
    def move(self): #NOTE THAT THIS IS WHERE CODE STOPS WORKING
        self.x = random(0, self.width - self.size) or self.size * self.size
        print("move")
        self.y = random(0, self.height - self.size) or self.size * self.size
    
    def display(self): # Display Method for Food
         # if col:
        #     self.x = int(random(self.width - self.size))
        #     print("move")
        #     self.y = random(self.height - self.size)
        #     col = False
        # else:
        image(loadImage("bananaXuanthaoT.png"), GRID_SIZE, GRID_SIZE, GRID_SIZE, GRID_SIZE)
