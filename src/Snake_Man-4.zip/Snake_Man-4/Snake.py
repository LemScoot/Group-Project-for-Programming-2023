class Snake(object):
    
    # Intergers
    global xpos
    global ypos
  
    # Constructor
    def __init__(self, xpos, ypos):
        self.xpos = xpos
        self.ypos = ypos

    def move(self, dir): # Move Method for Snake
        if(dir == 'w'):
            ypos =- 65
        elif(dir == 'a'):
            xpos =- 65
        elif(dir == 's'):
            ypos += 65
        elif(dir == 'd'):
            xpos += 65
    
    def draw(self): # Display Method for Snake
        fill(255, 174, 0)
        #snake.spines['top'].set_visible(False)
        #snake.spines['right'].set_visible(False)
        #snake.spines['bottom'].set_visible(False)
        #snake.spines['left'].set_visible(False)
        rect(92,92, 65, 65, 25)  # each square is 65/65 - first colum of squares is at 92
    
    # def grow(self):
    #    self.grow

    def intersect(Food, food):
        d = dist(x, y, food.x, food.y)
        if (d<50):
            return True
        else: 
            return False
