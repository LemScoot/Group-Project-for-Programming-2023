#used some code by MagicHatJo from their github repository 
class Snake(object):
    
    # Intergers
    global xpos
    global ypos
  
    # Constructor
    def __init__(self, size):
        self.x = 3 * size
        self.y = 3 * size
        self.vx = 1
        self.vy = 0
        self.size = 62.5
    
        self.body = [
        (self.x - size, self.y),
        (self.x - size * 2, self.y)
        ]
        
    def action(self, dir): # Move Method for Snake
        if key == "w" and self.vy != 1:
            self.vx = 0
            self.vy = -1
        if key == "a" and self.vx != 1:
            self.vx = -1
            self.vy = 0
        if key == "s" and self.vy != -1:
            self.vx = 0
            self.vy = 1
        if key == "d" and self.vx != -1:
            self.vx = 1
            self.vy = 0
            
    def update(self):
        self.body.pop(0)
        self.body.append((self.x, self.y))
        self.x += self.vx * self.size
        self.y += self.vy * self.size   
             
    def grow(self):
        self.body.insert(0, self.body[0])

    def draw(self): # Display Method for Snake
        fill(253, 208, 63)
        rect(self.x, self.y, self.size, self.size, 10)
        for part in self.body:
            rect(part[0], part[1], self.size, self.size, 10) 

    def intersect(Food, food):
        d = dist(x, y, food.x, food.y)
        if (d<GRID_SIZE):
            return True
        else: 
            return False
