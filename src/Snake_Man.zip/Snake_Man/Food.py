class Food(object):
    
# Intergers
    x = 0
    y = 0
    diam = 0

# Constructor        
    def __init__(self):
        self.x = 500
        self.y = -100
        self.diam = 10,10
        self.rand = int(random(3))
            
    def display(self): # Display Method for Food
        Img = ["appleXuanthaoT.png", "bananaXuanthaoT.png"]
        random.choice(Img)
        
    def move(self): # Move Method for Food
        self.x
        self.y
        for i in range(x, y):
            r = random(x, y)
            r.display()
