class Food(object):
    
# Intergers
    x = 0
    y = 0
    diam = 0

# Constructor        
    def __init__(self):
        self.x = 100
        self.y = -100
        self.diam = 1,1
        self.rand = int(random(3))
        #if rand == 0:
            
        #food_img = random.choice(['appleXuanthaoT.png', 'bananaXuanthaoT.png'])
        #image(loadImage(food_img), 0, 0)
    def display(self): # Display Method for Food
        #Img = ["appleXuanthaoT.png", "bananaXuanthaoT.png"]
        #random.choice(Img)
        Img = "appleXuanthaoT.png"
        
    def move(self): # Move Method for Food
        self.x
        self.y
        for i in range(x, y):
            r = random(x, y)
            r.display()
            
    def intersect(Snake, snake):
        s = dist(x, y, snake.x, snake.y)
        if (s<50):
            return True
        else: 
            return false
