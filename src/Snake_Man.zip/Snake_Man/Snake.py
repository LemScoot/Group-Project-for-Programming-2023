class Snake(object):
    
    # Intergers
    global xpos
    global ypos
  
    # Constructor
    def __init__(self, xpos, ypos):
        self.xpos = xpos
        self.ypos = ypos

    def move(self): # Move Method for Snake
        if(keyboard.is_pressed('w')):
            self.y = self.y - 0.1
        if(keyboard.is_pressed('s')):
            self.y = self.y + 0.1
        if(keyboard.is_pressed('a')):
            self.x = self.x - 0.1
        if(keyboard.is_pressed('d')):
            self.x = self.x + 0.1
    
        self.snake.goto(self.x,self.y)
    
    def draw(self): # Display Method for Snake
        fill(255, 174, 0)
        #snake.spines['top'].set_visible(False)
        #snake.spines['right'].set_visible(False)
        #snake.spines['bottom'].set_visible(False)
       # snake.spines['left'].set_visible(False)
        rect(92,92, 65, 65, 25)  # each square is 65/65 - first colum of squares is at 92
    
  #  def grow(self):
  #      self.grow.

    def intersect(Food, food):
        d = dist(x, y, food.x, food.y)
        if (d<50):
            return True
        else: 
            return False
